Welcome to the Bidone Android Coding Test!

You should:
1. Fix any issues preventing the app from compiling.
2. Display the list of orders, as well as the products each order contains.

You may add any libraries and change and move around any code you choose, as long as the original data remains the same.

You should spend no more than a few hours on this test. Once complete, zip the project back up and send to the person who requested it.

Make sure to show off your skills.

Good luck!