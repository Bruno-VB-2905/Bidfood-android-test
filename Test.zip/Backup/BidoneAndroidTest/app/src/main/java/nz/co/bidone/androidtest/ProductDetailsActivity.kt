package nz.co.bidone.androidtest

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider

class ProductDetailsActivity : AppCompatActivity() {
    private lateinit var viewModel2: MainActivityViewModel
    private lateinit var clazz2: Product

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.products_list_view)

        clazz2 = Product(0,"","",0.0,0.0)

        viewModel2 = ViewModelProvider(this).get(MainActivityViewModel::class.java)



        val listView = findViewById(R.id.listProducts) as ListView
        val listAdapter = MyAdapter2(this, viewModel2, clazz2)
        listView.adapter = listAdapter


    }
}

class MyAdapter2(context: Context, viewModel: MainActivityViewModel, clazz: Product): BaseAdapter(){
    private val context: Context = context

    val value = viewModel

    val product = clazz

    override fun getCount(): Int {
        return value.orders.value!!.size
    }

    override fun getItem(position: Int): Any {
        return value.orders.value!![position].products[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val layoutInflater = LayoutInflater.from(context)
        val row = layoutInflater.inflate(R.layout.list_row2, parent, false)


        val codeTextView = row.findViewById(R.id.textViewCode) as TextView
        codeTextView.text = product.productCode.toString()

        val descTextView = row.findViewById(R.id.textViewDescription2) as TextView
        descTextView.text = value.orders.value!![position].products[0].toString()



        println("product code: ${value.orders.value!![position].products}")


        return row
    }
}
