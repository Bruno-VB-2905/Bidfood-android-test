package nz.co.bidone.androidtest

import java.util.*

class Order(
    val id: Int,
    val description: String,
    val orderDate: String,
    val deliveryDate: String?,
    val products: List<Product>,
    //val totalprice: Double
) {
    // Returns total value of products in order
    fun getOrderTotal(): Product {
        //TODO
        var clazz: Product
        clazz = products[3]
        products.sumOf { clazz.price }
        return products[3]
    }
}
