package nz.co.bidone.androidtest

data class Product(
    var productCode: Int,
    val description: String,
    val brand: String,
    val price: Double,
    val quantity: Double
)
