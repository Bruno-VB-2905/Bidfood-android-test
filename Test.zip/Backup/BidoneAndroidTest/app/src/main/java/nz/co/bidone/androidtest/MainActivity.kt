package nz.co.bidone.androidtest


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.joinAll
import nz.co.bidone.androidtest.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: MainActivityViewModel
    private lateinit var clazz: Product

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
        clazz = Product(0,"","",0.0,0.0)

        val listView = findViewById(R.id.listOrders) as ListView
        val listAdapter = MyAdapter(this, viewModel, clazz)
        listView.adapter = listAdapter

        listView.setOnItemClickListener { parent, view, position, id ->
            val products = viewModel.orders.value!![position].products[position]
            val intent = Intent(applicationContext, ProductDetailsActivity::class.java)

            startActivity(intent)
        }
    }
}


class MyAdapter(context: Context, viewModel: MainActivityViewModel, clazz: Product): BaseAdapter(){
    private val context: Context = context

    val value = viewModel

    val product = clazz

    override fun getCount(): Int {
        return value.orders.value!!.size
    }

    override fun getItem(position: Int): Any {
        return value.orders.value!![position].products
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val layoutInflater = LayoutInflater.from(context)
        val row = layoutInflater.inflate(R.layout.list_row, parent, false)
        val row2 = layoutInflater.inflate(R.layout.list_row2, parent, false)

        val idText = row.findViewById(R.id.textViewID) as TextView
        idText.text = value.orders.value!![position].id.toString()
        val descriptionText = row.findViewById(R.id.textViewDescription) as TextView
        descriptionText.text = value.orders.value!![position].description
        val orderdateText = row.findViewById(R.id.textViewOrderDate) as TextView
        orderdateText.text = value.orders.value!![position].orderDate
        val deliverydateText = row.findViewById(R.id.textViewDeliveryDate) as TextView
        deliverydateText.text = value.orders.value!![position].deliveryDate
        val productsText = row.findViewById(R.id.textViewProducts) as TextView
        productsText.text = value.orders.value!![position].products.toString()

        println("product code: ${value.orders.value!![position].products}")


        return row
    }
}





