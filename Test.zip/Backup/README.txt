Had only used kotlin once or twice before this which is why it isnt the best.
I have a project similar to this but the data is structured in a different way.

I completed the first point within 10 min, which was the compile error.
	when first opened project and built I saw the error in the debugger, and
	it said there was a issue writing to a specific directory,
	C:\Users\Bruno\Desktop\BidfoodTest\BidoneAndroidTest\app\build\intermediates\runtime_symbol_list\debug\R.
		
	When I went to the directory there was no file R.txt. So I looked at past practice apps or past projects
	and they all had R.txt and were largely the same.So I copied it over and ran it and there was no more compile error.

The rest was a bit more complicated as this was the second time using kotlin;
This point took around 2-3hours.
	Everything displays for the list view. However when it came to displaying the products there were some problems.
	
	I couldn't extract singular objects for a cleaner design for the products to intent to the next screen, which was annoying as I believe I could have done this if using another way of storing the data.

	Otherwise you can still view the products for the order it just isnt neet.
